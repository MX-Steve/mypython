#!/bin/bash
echo -e "\x1b[31m\x1b[5mHello world\x1b[25m\x1b[39m"
